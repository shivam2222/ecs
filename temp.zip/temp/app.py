import json,time
from unittest.case import _AssertRaisesContext
from flask import Flask,render_template,request,Response
import threading
from threading import Thread
from json import dumps
import uuid

app = Flask(__name__)

@app.route("/")
def hello():
  return render_template('index.html')

@app.route('/addData',methods = ["POST","GET"])
def addData():
  responseId = uuid.uuid4().hex
  thread = Thread(target=createapi,args=())
  thread.start()
  return Response(dumps({'code':202,'message':'success','responseId':responseId}), 202)



def createapi():
  global assetResponse
  assetResponse =  {
    "repository": {
      "status": "success",
      "statusMessage": "Repository has been successfully created",
      "apiPath": "https://gerrit.ericsson.se/a/EBIP/API-GW/API/AutomaticDeployment/1.0.0",
      "esbPackagePath": [
        "https://gerrit.ericsson.se/a/EBIP/API-GW/IS/AutomaticDeployment-ESB/GatewayCode/AutomaticDeployment-ESB"
      ]
    }
  }
  time.sleep(20)
  assetResponse = {
    "repository": {
      "status": "success",
      "statusMessage": "Repository has been successfully created",
      "apiPath": "https://gerrit.ericsson.se/a/EBIP/API-GW/API/AutomaticDeployment/1.0.0",
      "esbPackagePath": [
        "https://gerrit.ericsson.se/a/EBIP/API-GW/IS/AutomaticDeployment-ESB/GatewayCode/AutomaticDeployment-ESB"
      ]
    },
    "aliasCreation": {
      "status": "success",
      "aliases": [
        {
          "aliasName": "ECP_SolutionDB_Azure_Endpoint",
          "status": "ECP_SolutionDB_Azure_Endpoint : Created Successfully"
        }
      ]
    }
  }
  time.sleep(10)
  assetResponse = {
    "repository": {
      "status": "success",
      "statusMessage": "Repository has been successfully created",
      "apiPath": "https://gerrit.ericsson.se/a/EBIP/API-GW/API/AutomaticDeployment/1.0.0",
      "esbPackagePath": [
        "https://gerrit.ericsson.se/a/EBIP/API-GW/IS/AutomaticDeployment-ESB/GatewayCode/AutomaticDeployment-ESB"
      ]
    },
    "aliasCreation": {
      "status": "success",
      "aliases": [
        {
          "aliasName": "ECP_SolutionDB_Azure_Endpoint",
          "status": "ECP_SolutionDB_Azure_Endpoint : Created Successfully"
        }
      ]
    },
    "apiCreation": {
      "status": "success",
      "statusMessage": "AutomaticDeployment : Created Successfully"
    }
  }
  time.sleep(20)
  assetResponse ={
    "repository": {
      "status": "success",
      "statusMessage": "Repository has been successfully created",
      "apiPath": "https://gerrit.ericsson.se/a/EBIP/API-GW/API/AutomaticDeployment/1.0.0",
      "esbPackagePath": [
        "https://gerrit.ericsson.se/a/EBIP/API-GW/IS/AutomaticDeployment-ESB/GatewayCode/AutomaticDeployment-ESB"
      ]
    },
    "aliasCreation": {
      "status": "success",
      "aliases": [
        {
          "aliasName": "ECP_SolutionDB_Azure_Endpoint",
          "status": "ECP_SolutionDB_Azure_Endpoint : Created Successfully"
        }
      ]
    },
    "apiCreation": {
      "status": "success",
      "statusMessage": "AutomaticDeployment : Created Successfully"
    },
    "portalPublish": {
      "status": "success",
      "portalLink": "https://apiportal-qa.ericsson.net/#default/apiDetails/c.restObject.API-Portal.UmleQdqHEewmFwAd2Mc4wg.-1",
      "statusMessage": "Published to Portal Successfully!!"
    }
}


@app.route('/getStatus', methods=["GET"])
def getStatus():
  return Response(dumps(assetResponse), 200)



if __name__ == "__main__":
  app.run(debug=True)