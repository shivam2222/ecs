var p;
// let ct = 0;
async function poll() {
  console.log("in poll");
  let result = await $.get("/getStatus");
  result = JSON.parse(result);
  // ct += 1;
  // if (ct == 11) {
  //   clearInterval(p);
  // }
  if (result["repository"]) {
    if (result["repository"]["status"] === "error") {
      $("#response").html("Error");
      clearInterval(p);
    } else {
      $("#response").html("Success Repository");
    }
  }

  if (result["aliasCreation"]) {
    if (result["aliasCreation"]["status"] === "error") {
      $("#response").html("Error");
      clearInterval(p);
    } else {
      $("#response").html("Success aliasCreation");
    }
  }
  if (result["apiCreation"]) {
    if (result["apiCreation"]["status"] === "error") {
      $("#response").html("Error");
      clearInterval(p);
    } else {
      $("#response").html("Success apiCreation");
    }
  }
  if (result["portalPublish"]) {
    if (result["portalPublish"]["status"] === "success") {
      $("#response").html("Success portalPublish");
      clearInterval(p);
    } else {
      $("#response").html("Error portalPublish");
      clearInterval(p);
    }
    // $("#response").html("Success portalPublish");
  }
}
function put_data(data) {
  data = JSON.parse(data);
  console.log(data);
  // $("#response").html("Form Get Submited");
}
$(document).ready(function () {
  $("form").on("submit", function (event) {
    $.ajax({
      type: "POST",
      url: "/addData",

      success: function (data) {
        // console.log(data);
        put_data(data);
        p = setInterval(poll, 5000);
        //   $("#response").html(data);
      },
      beforeSend: function () {
        $("#fname").val("");
        $("#response").html("<div class='text-center'>Loading</div>");
      },
      error: function (data) {
        $("#response").html("Error");
      },
    });
    event.preventDefault();
  });
});
