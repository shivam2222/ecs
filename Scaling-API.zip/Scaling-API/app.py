
import json
from flask import Flask,render_template,request
app = Flask(__name__)

@app.route("/")
def hello():
  return render_template('index.html')

@app.route('/addData',methods = ["POST","GET"])
def addData():
  fname = request.form["fname"]
  lname = request.form["lname"]
  output = {}
  output["fname"] = fname
  output["lname"] = lname
  return json.dumps(output)



@app.route('/getStatus', methods=["GET"])
def getStatus():
  return "Saved"

if __name__ == "__main__":
  app.run()