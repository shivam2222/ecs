var counter = 1;
var p;
async function poll() {
  console.log("in poll");
  const result = await $.get("/getStatus");
  counter += 1;

  console.log(result);
  console.log("Hello");
  if (counter === 5) {
    clearInterval(p);
  }
}
function put_data(data) {
  data = JSON.parse(data);
  console.log(data);
  $("#response").html("Form Get Submited");
}
$(document).ready(function () {
  $("form").on("submit", function (event) {
    $.ajax({
      type: "POST",
      url: "/addData",
      data: {
        fname: $("#fname").val(),
        lname: $("#lname").val(),
      },
      success: function (data) {
        // console.log(data);
        put_data(data);
        p = setInterval(poll, 5000);
        //   $("#response").html(data);
      },
      beforeSend: function () {
        $("#lname").val("");
        $("#fname").val("");
        $("#response").html("<div class='text-center'>Loading</div>");
      },
      error: function (data) {
        $("#response").html("Error");
      },
    });
    event.preventDefault();
  });
});
